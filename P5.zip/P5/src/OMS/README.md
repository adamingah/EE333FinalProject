# EE333P5
>
> Adam Ingah, Jonathan Myers, Tyler Brasher
>
This is a final project for EE333 (Engineering Programming using objects) that is an application built in Java. 
The functionality of the application is to behave like a primitive e-commerce ordering system that allows
for simple functionality like adding customers, managing orders, etc.
