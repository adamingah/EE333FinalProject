/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OMS;

/**
 *
 * @author jmyer
 */
public class Interfaces {
    
    // To-Do: Figure out how to implement importable interface.
    interface exportable {
        public String toString();
        public String toCSV();
        public String toCustom();
    }
    
    
}
